Your task: Decode the secret message.
Rules: You are allowed to use any online resource. 
Hint: the secret message begins with UGVDTU

